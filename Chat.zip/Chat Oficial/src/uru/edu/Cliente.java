package uru.edu;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.*;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.net.*;
import javax.swing.JTextArea;
import java.awt.Color;

public class Cliente extends JFrame implements Runnable {

	private JPanel contentPane;
	private JTextField textField;
	private JTextArea textArea;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente frame = new Cliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cliente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 277, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCliente = new JLabel("CHAT");
		lblCliente.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblCliente.setBounds(95, 9, 74, 14);
		contentPane.add(lblCliente);
		
		JButton botonEnviar = new JButton("Enviar");
		botonEnviar.setBounds(162, 227, 89, 23);
		EnviarTexto mievento=new EnviarTexto();
		botonEnviar.addActionListener(mievento);
		contentPane.add(botonEnviar);
		
		textField = new JTextField();
		textField.setBounds(10, 228, 148, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textArea = new JTextArea();
		textArea.setBounds(10, 30, 241, 186);
		contentPane.add(textArea);
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 9, 61, 16);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(149, 9, 102, 16);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		Thread mihilo=new Thread(this);
		mihilo.start();          
	}
	private class EnviarTexto implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			textArea.append("\n" + textField.getText() );
			
			try {
				Socket miSocket = new Socket(InetAddress.getLocalHost(), 9999);
				
				TodoEnvio datos=new TodoEnvio();
				datos.setNick(textField_1.getText());
				datos.setIp(textField_2.getText());
				datos.setMensaje(textField.getText());
				ObjectOutputStream paquete_datos=new ObjectOutputStream(miSocket.getOutputStream());
				paquete_datos.writeObject(datos);
				miSocket.close();
				//DataOutputStream flujo_salida = new DataOutputStream (miSocket.getOutputStream());
				//flujo_salida.writeUTF(textField.getText());
				//flujo_salida.close();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			//System.out.println(textField.getText());
		}
		
	}
	class TodoEnvio implements Serializable {
		private String nick,ip,mensaje;

		public String getNick() {
			return nick;
		}

		public void setNick(String nick) {
			this.nick = nick;
		}

		public String getIp() {
			return ip;
		}

		public void setIp(String ip) {
			this.ip = ip;
		}

		public String getMensaje() {
			return mensaje;
		}

		public void setMensaje(String mensaje) {
			this.mensaje = mensaje;
		}
		
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			ServerSocket servidor_cliente=new ServerSocket(9090);
			Socket cliente;
			TodoEnvio paqueteRecibido;
			while(true) {
				
				cliente=servidor_cliente.accept();
				ObjectInputStream flujoentrada = new ObjectInputStream(cliente.getInputStream());
				paqueteRecibido=(TodoEnvio) flujoentrada.readObject();
				textArea.append("\n" + paqueteRecibido.getNick() + ": " + paqueteRecibido.getMensaje());
			}
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
