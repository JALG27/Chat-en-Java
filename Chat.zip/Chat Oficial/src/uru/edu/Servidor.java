package uru.edu;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.IOException;
import java.io.*;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import uru.edu.Cliente.TodoEnvio;

import javax.swing.JTextField;
import java.net.*;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Servidor extends JFrame implements Runnable {

	private JPanel miventana;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Servidor frame = new Servidor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
	}
	

	/**
	 * Create the frame.
	 */
	public Servidor() {
		setBounds(1200,300,280,350);
		JPanel miventana = new JPanel();
		miventana.setLayout(new BorderLayout());
		textArea= new JTextArea();
		miventana.add(textArea,BorderLayout.CENTER);
		add(miventana);
		setVisible(true);
		Thread mihilo = new Thread(this);
		mihilo.start();

		
	}
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			ServerSocket Servidor = new ServerSocket (9999);
			String nick,ip,mensaje;
			TodoEnvio paquete_recibido;
			while (true) {
			Socket misocket = Servidor.accept();
			ObjectInputStream paquete_datos=new ObjectInputStream(misocket.getInputStream());
			paquete_recibido=(TodoEnvio) paquete_datos.readObject();
			nick=paquete_recibido.getNick();
			ip=paquete_recibido.getIp();
			mensaje=paquete_recibido.getMensaje();
			//DataInputStream flujo_entrada = new DataInputStream(misocket.getInputStream());
			//String mensaje_texto=flujo_entrada.readUTF();
			//textArea.append("\n" + mensaje_texto);
			textArea.append("\n" + nick + ":" + mensaje + " para " + ip);
			Socket EnviaDestinatario=new Socket(ip,9090);
			ObjectOutputStream paqueteReenvio=new ObjectOutputStream(EnviaDestinatario.getOutputStream());
			paqueteReenvio.writeObject(paquete_recibido);
			paqueteReenvio.close();
			EnviaDestinatario.close();
			misocket.close();
			}
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
